; HEADER_BLOCK_START
; BambuStudio 02.08.02.61
; model printing time: 2m 27s; total estimated time: 8m 31s
; total layer number: 14
; total filament length [mm] : 119.74
; total filament volume [cm^3] : 288.01
; total filament weight [g] : 0.36
; filament_density: 1.24
; filament_diameter: 1.75
; max_z_height: 2.80
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 70
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.7,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = monotonic
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 50
; brim_object_gap = 0.1
; brim_type = outer_only
; brim_width = 5
; chamber_temperatures = 0
; change_filament_gcode = ;===== A1mini 20251031 =====\nG392 S0\nM1007 S0\nM620 S[next_extruder]A\nM204 S9000\nG1 Z{max_layer_z + 3.0} F1200\n\nM400\nM106 P1 S0\nM106 P2 S0\n{if old_filament_temp > 142 && next_extruder < 255}\nM104 S[old_filament_temp]\n{endif}\n\nG1 X180 F18000\n\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E-{retraction_distances_when_cut[previous_extruder]} F1200\n{else}\nM620.11 S0\n{endif}\nM400\n\nM620.1 E F{flush_volumetric_speeds[previous_extruder]/2.4053*60} T{flush_temperatures[previous_extruder]}\nM620.10 A0 F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nT[next_extruder]\nM620.1 E F{flush_volumetric_speeds[next_extruder]/2.4053*60} T{flush_temperatures[next_extruder]}\nM620.10 A1 F{flush_volumetric_speeds[next_extruder]/2.4053*60} L[flush_length] H[nozzle_diameter] T{flush_temperatures[next_extruder]}\n\nG1 Y90 F9000\n\n{if next_extruder < 255}\n\n{if long_retractions_when_cut[previous_extruder]}\nM620.11 S1 I[previous_extruder] E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM628 S1\nG92 E0\nG1 E{retraction_distances_when_cut[previous_extruder]} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nM400\nM629 S1\n{else}\nM620.11 S0\n{endif}\n\nM400\nG92 E0\nM628 S0\n\n{if flush_length_1 > 1}\n; FLUSH_START\n; always use highest temperature to flush\nM400\nM1002 set_filament_type:UNKNOWN\nM109 S[flush_temperatures[next_extruder]]\nM106 P1 S60\n{if flush_length_1 > 23.7}\nG1 E23.7 F{flush_volumetric_speeds[previous_extruder]/2.4053*60} ; do not need pulsatile flushing for start part\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{(flush_length_1 - 23.7) * 0.02} F50\nG1 E{(flush_length_1 - 23.7) * 0.23} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\n{else}\nG1 E{flush_length_1} F{flush_volumetric_speeds[previous_extruder]/2.4053*60}\n{endif}\n; FLUSH_END\nG1 E-[old_retract_length_toolchange] F1800\nG1 E[old_retract_length_toolchange] F300\nM400\nM1002 set_filament_type:{filament_type[next_extruder]}\n{endif}\n\n{if flush_length_1 > 45 && flush_length_2 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_2 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\nG1 E{flush_length_2 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_2 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_2 > 45 && flush_length_3 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_3 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\nG1 E{flush_length_3 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_3 * 0.02} F50\n; FLUSH_END\nG1 E-[new_retract_length_toolchange] F1800\nG1 E[new_retract_length_toolchange] F300\n{endif}\n\n{if flush_length_3 > 45 && flush_length_4 > 1}\n; WIPE\nM400\nM106 P1 S178\nM400 S3\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nM400\nM106 P1 S0\n{endif}\n\n{if flush_length_4 > 1}\nM106 P1 S60\n; FLUSH_START\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\nG1 E{flush_length_4 * 0.18} F{flush_volumetric_speeds[next_extruder]/2.4053*60}\nG1 E{flush_length_4 * 0.02} F50\n; FLUSH_END\n{endif}\n\nM629\n\nM400\nM106 P1 S60\nM109 S[new_filament_temp]\nG1 E5 F{flush_volumetric_speeds[next_extruder]/2.4053*60} ;Compensate for filament spillage during waiting temperature\nM400\nG92 E0\nG1 E-[new_retract_length_toolchange] F1800\nM400\nM106 P1 S178\nM400 S3\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nG1 X-3.5 F18000\nG1 X-13.5 F3000\nM400\nG1 Z{max_layer_z + 3.0} F3000\nM106 P1 S0\n{if layer_z <= (initial_layer_print_height + 0.001)}\nM204 S[initial_layer_acceleration]\n{else}\nM204 S[default_acceleration]\n{endif}\n{else}\nG1 X[x_after_toolchange] Y[y_after_toolchange] Z[z_after_toolchange] F12000\n{endif}\n\nM622.1 S0\nM9833 F{outer_wall_volumetric_speed/2.4} A0.3 ; cali dynamic extrusion compensation\nM1002 judge_flag filament_need_cali_flag\nM622 J1\n  G92 E0\n  G1 E-[new_retract_length_toolchange] F1800\n  M400\n  \n  M106 P1 S178\n  M400 S7\n  G1 X0 F18000\n  G1 X-13.5 F3000\n  G1 X0 F18000 ;wipe and shake\n  G1 X-13.5 F3000\n  G1 X0 F12000 ;wipe and shake\n  G1 X-13.5 F3000\n  G1 X0 F12000 ;wipe and shake\n  M400\n  M106 P1 S0 \nM623\n\nM621 S[next_extruder]A\nG392 S0\n\nM1007 S1\n
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; compatible_printers_condition = 
; complete_print_exhaust_fan_speed = 70
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.008
; counter_coef_3 = -0.041
; counter_limit_max = 0.033
; counter_limit_min = -0.035
; counterbore_hole_bridging = none
; curr_bed_type = Textured PEI Plate
; default_acceleration = 6000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL A1M"
; default_jerk = 0
; default_nozzle_volume_type = Standard
; default_print_profile = 0.20mm Standard @BBL A1M
; deretraction_speed = 30
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 70
; elefant_foot_compensation = 0
; embedding_wall_into_infill = 0
; enable_arc_fitting = 1
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 1
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 0
; eng_plate_temp_initial_layer = 0
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 56.5
; extruder_clearance_height_to_lid = 180
; extruder_clearance_height_to_rod = 25
; extruder_clearance_max_radius = 73
; extruder_colour = #018001
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_type = Direct Drive
; extruder_variant_list = "Direct Drive Standard"
; fan_cooling_layer_time = 80
; fan_direction = undefine
; fan_max_speed = 80
; fan_min_speed = 60
; farthest_point_timelapse = 0
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 100
; filament_bridge_speed = 25
; filament_change_length = 10
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 0
; filament_cost = 20
; filament_density = 1.24
; filament_dev_ams_drying_ams_limitations = 1
; filament_dev_ams_drying_heat_distortion_temperature = 45
; filament_dev_ams_drying_temperature = 45
; filament_dev_ams_drying_time = 12
; filament_dev_chamber_drying_bed_temperature = 70
; filament_dev_chamber_drying_time = 12
; filament_dev_drying_cooling_temperature = 45
; filament_dev_drying_softening_temperature = 50
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = "; filament end gcode \n\n"
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 0.98
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = GFL99
; filament_is_mixed = 0
; filament_is_support = 0
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 12
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 50
; filament_overhang_3_4_speed = 30
; filament_overhang_4_4_speed = 10
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 0
; filament_prime_volume = 45
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 14
; filament_scarf_gap = 15%
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Generic PLA @BBL A1M"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = "; filament start gcode\n{if  (bed_temperature[current_extruder] >45)||(bed_temperature_initial_layer[current_extruder] >45)}M106 P3 S255\n{elsif(bed_temperature[current_extruder] >35)||(bed_temperature_initial_layer[current_extruder] >35)}M106 P3 S180\n{endif};Prevent PLA from jamming\n\n\n{if activate_air_filtration[current_extruder] && support_air_filtration}\nM106 P3 S{during_print_exhaust_fan_speed_num[current_extruder]} \n{endif}"
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = Generic
; filament_volume_map = 0
; filename_format = {input_filename_base}_{filament_type[0]}_{print_time}.gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 250
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 17.4
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 156x152,180x152,180x180,156x180
; hole_coef_1 = 0
; hole_coef_2 = -0.008
; hole_coef_3 = 0.23415
; hole_limit_max = 0.22
; hole_limit_min = 0.088
; hot_plate_temp = 60
; hot_plate_temp_initial_layer = 60
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 10
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 500
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 105
; initial_layer_jerk = 9
; initial_layer_line_width = 0.5
; initial_layer_print_height = 0.2
; initial_layer_speed = 50
; initial_layer_travel_acceleration = 6000
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.45
; inner_wall_speed = 300
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0.8
; internal_solid_infill_line_width = 0.42
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 250
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0.21
; ironing_pattern = zig-zag
; ironing_spacing = 0.15
; ironing_speed = 30
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = ; layer num/total_layer_count: {layer_num+1}/[total_layer_count]\n; update layer progress\nM73 L{layer_num+1}\nM991 S0 P{layer_num} ;notify layer change
; layer_height = 0.2
; line_width = 0.42
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = ;===== date: 20260513 =====================\n;turn off nozzle clog detect\nG392 S0\n\nM400 ; wait for buffer to clear\nG92 E0 ; zero the extruder\nG90\nG1 Z{max_layer_z + 0.4} F900 ; lower z a little\nG1 X0 Y{first_layer_center_no_wipe_tower[1]} F18000 ; move to safe pos\nG1 X-13.0 F3000 ; move to safe pos\n{if !spiral_mode && print_sequence != \"by object\"}\nM1002 judge_flag timelapse_record_flag\nM622 J1\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM400 P100\nM971 S11 C11 O0\nM991 S0 P-1 ;end timelapse at safe pos\nM623\n{endif}\n\nM140 S0 ; turn off bed\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off remote part cooling fan\nM106 P3 S0 ; turn off chamber cooling fan\n\n;G1 X27 F15000 ; wipe\n\n; pull back filament to AMS\nM620 S255\nG1 X181 F12000\nT255\nG1 X0 F18000\nG1 X-13.0 F3000\nG1 X0 F18000 ; wipe\nM621 S255\n\nM104 S0 ; turn off hotend\n\nM400 ; wait all motion done\nM17 S\nM17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom\n{if (max_layer_z + 100.0) < 180}\n    G1 Z{max_layer_z + 100.0} F600\n    G1 Z{max_layer_z +98.0}\n{else}\n    G1 Z180 F600\n    G1 Z180\n{endif}\nM400 P100\nM17 R ; restore z current\n\nG90\nG1 X-13 Y180 F3600\n\nG91\nG1 Z-1 F600\nG90\nM83\n\nM220 S100  ; Reset feedrate magnitude\nM201.2 K1.0 ; Reset acc magnitude\nM73.2   R1.0 ;Reset left time magnitude\nM1002 set_gcode_claim_speed_level : 0\n\n;=====printer finish  sound=========\nM17\nM400 S1\nM1006 S1\nM1006 A0 B20 L100 C37 D20 M100 E42 F20 N100\nM1006 A0 B10 L100 C44 D10 M100 E44 F10 N100\nM1006 A0 B10 L100 C46 D10 M100 E46 F10 N100\nM1006 A44 B20 L100 C39 D20 M100 E48 F20 N100\nM1006 A0 B10 L100 C44 D10 M100 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B10 L100 C39 D10 M100 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B10 L100 C44 D10 M100 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B10 L100 C39 D10 M100 E39 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A44 B10 L100 C0 D10 M100 E48 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A44 B20 L100 C41 D20 M100 E49 F20 N100\nM1006 A0 B20 L100 C0 D20 M100 E0 F20 N100\nM1006 A0 B20 L100 C37 D20 M100 E37 F20 N100\nM1006 W\n;=====printer finish  sound=========\nM400 S1\nM18 X Y Z\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 28
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 20000,20000
; machine_max_acceleration_retracting = 5000,5000
; machine_max_acceleration_travel = 6000,6000
; machine_max_acceleration_x = 6000,6000
; machine_max_acceleration_y = 6000,6000
; machine_max_acceleration_z = 1500,1500
; machine_max_force_Y = 0
; machine_max_jerk_e = 3,3
; machine_max_jerk_x = 9,9
; machine_max_jerk_y = 9,9
; machine_max_jerk_z = 5,5
; machine_max_printed_mass = 0
; machine_max_speed_e = 30,30
; machine_max_speed_x = 500,200
; machine_max_speed_y = 500,200
; machine_max_speed_z = 30,30
; machine_min_extruding_rate = 0,0
; machine_min_travel_rate = 0,0
; machine_pause_gcode = M400 U1
; machine_prepare_compensation_time = 260
; machine_start_gcode = ;===== machine: A1 mini =========================\n;===== date: 20260513 ==================\n\n;===== start to heat heatbead&hotend==========\nM1002 gcode_claim_action : 2\nM1002 set_filament_type:{filament_type[initial_no_support_extruder]}\nM104 S170\nM140 S[bed_temperature_initial_layer_single]\nG392 S0 ;turn off clog detect\nM9833.2\n;=====start printer sound ===================\nM17\nM400 S1\nM1006 S1\nM1006 A0 B0 L100 C37 D10 M100 E37 F10 N100\nM1006 A0 B0 L100 C41 D10 M100 E41 F10 N100\nM1006 A0 B0 L100 C44 D10 M100 E44 F10 N100\nM1006 A0 B10 L100 C0 D10 M100 E0 F10 N100\nM1006 A43 B10 L100 C39 D10 M100 E46 F10 N100\nM1006 A0 B0 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B0 L100 C39 D10 M100 E43 F10 N100\nM1006 A0 B0 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B0 L100 C41 D10 M100 E41 F10 N100\nM1006 A0 B0 L100 C44 D10 M100 E44 F10 N100\nM1006 A0 B0 L100 C49 D10 M100 E49 F10 N100\nM1006 A0 B0 L100 C0 D10 M100 E0 F10 N100\nM1006 A44 B10 L100 C39 D10 M100 E48 F10 N100\nM1006 A0 B0 L100 C0 D10 M100 E0 F10 N100\nM1006 A0 B0 L100 C39 D10 M100 E44 F10 N100\nM1006 A0 B0 L100 C0 D10 M100 E0 F10 N100\nM1006 A43 B10 L100 C39 D10 M100 E46 F10 N100\nM1006 W\nM18\n;=====avoid end stop =================\nG91\nG380 S2 Z30 F1200\nG380 S3 Z-20 F1200\nG1 Z5 F1200\nG90\n\n;===== reset machine status =================\nM204 S6000\n\nM630 S0 P0\nG91\nM17 Z0.3 ; lower the z-motor current\n\nG90\nM17 X0.7 Y0.9 Z0.5 ; reset motor current to default\nM960 S5 P1 ; turn on logo lamp\nG90\nM83\nM220 S100 ;Reset Feedrate\nM221 S100 ;Reset Flowrate\nM73.2   R1.0 ;Reset left time magnitude\n;====== cog noise reduction=================\nM982.2 S1 ; turn on cog noise reduction\n\n;===== prepare print temperature and material ==========\nM400\nM18\nM109 S100 H170\nM104 S170\nM400\nM17\nM400\nG28 X\n\nM211 X0 Y0 Z0 ;turn off soft endstop ; turn off soft endstop to prevent protential logic problem\n\nM975 S1 ; turn on\n\nG1 X0.0 F30000\nG1 X-13.5 F3000\n\nM620 M ;enable remap\nM620 S[initial_no_support_extruder]A   ; switch material if AMS exist\n    G392 S0 ;turn on clog detect\n    M1002 gcode_claim_action : 4\n    M400\n    M1002 set_filament_type:UNKNOWN\n    M109 S[nozzle_temperature_initial_layer]\n{if (filament_type[initial_no_support_extruder] == \"PLA\") && (nozzle_diameter != 0.2)}\n    M104 S220\n{else}\n    M104 S250\n{endif}\n    M400\n    T[initial_no_support_extruder]\n    G1 X-13.5 F3000\n    M400\n{if (filament_type[initial_no_support_extruder] == \"PLA\") && (nozzle_diameter != 0.2)}\n    M620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T220\n    M109 S220 ;set nozzle to common flush temp\n{else}\n    M620.1 E F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60} T{flush_temperatures[initial_no_support_extruder]}\n    M109 S250 ;set nozzle to common flush temp\n{endif}\n    M106 P1 S0\n    G92 E0\n    G1 E50 F200\n    M400\n    M1002 set_filament_type:{filament_type[initial_no_support_extruder]}\n{if (filament_type[initial_no_support_extruder] == \"PLA\") && (nozzle_diameter != 0.2)}\n    M104 S220\n{else}\n    M104 S{flush_temperatures[initial_no_support_extruder]}\n{endif}\n    G92 E0\n    G1 E50 F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60}\n    M400\n    M106 P1 S178\n    G92 E0\n    G1 E5 F{flush_volumetric_speeds[initial_no_support_extruder]/2.4053*60}\n    M109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-20} ; drop nozzle temp, make filament shink a bit\n    M104 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-40}\n    G92 E0\n    G1 E-0.5 F300\n\n    G1 X0 F30000\n    G1 X-13.5 F3000\n    G1 X0 F30000 ;wipe and shake\n    G1 X-13.5 F3000\n    G1 X0 F12000 ;wipe and shake\n    G1 X0 F30000\n    G1 X-13.5 F3000\n    M109 S{nozzle_temperature_initial_layer[initial_no_support_extruder]-40}\n    G392 S0 ;turn off clog detect\nM621 S[initial_no_support_extruder]A\n\nM400\nM106 P1 S0\n;===== prepare print temperature and material end =====\n\n\n;===== mech mode fast check============================\nM1002 gcode_claim_action : 3\nG0 X25 Y175 F20000 ; find a soft place to home\n;M104 S0\nG28 Z P0 T300; home z with low precision,permit 300deg temperature\nG29.2 S0 ; turn off ABL\nM104 S170\n\n; build plate detect\nM1002 judge_flag build_plate_detect_flag\nM622 S1\n  G39.4\n  M400\nM623\n\nG1 Z5 F3000\nG1 X90 Y-1 F30000\nM400 P200\nM970.3 Q1 A7 K0 O2\nM974 Q1 S2 P0\n\nG1 X90 Y0 Z5 F30000\nM400 P200\nM970 Q0 A10 B50 C90 H15 K0 M20 O3\nM974 Q0 S2 P0\n\nM975 S1\nG1 F30000\nG1 X-1 Y10\nG28 X ; re-home XY\n\n;===== wipe nozzle ===============================\nM1002 gcode_claim_action : 14\nM975 S1\n\nM104 S170 ; set temp down to heatbed acceptable\nM106 S255 ; turn on fan (G28 has turn off fan)\nM211 S; push soft endstop status\nM211 X0 Y0 Z0 ;turn off Z axis endstop\n\nM83\nG1 E-1 F500\nG90\nM83\n\nM109 S170\nM104 S140\nG0 X90 Y-4 F30000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X91 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X92 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X93 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X94 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X95 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X96 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X97 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X98 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X99 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X99 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X99 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X99 F10000\nG380 S3 Z-5 F1200\nG1 Z2 F1200\nG1 X99 F10000\nG380 S3 Z-5 F1200\n\nG1 Z5 F30000\n;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\nG1 X25 Y175 F30000.1 ;Brush material\nG1 Z0.2 F30000.1\nG1 Y185\nG91\nG1 X-30 F30000\nG1 Y-2\nG1 X27\nG1 Y1.5\nG1 X-28\nG1 Y-2\nG1 X30\nG1 Y1.5\nG1 X-30\nG90\nM83\n\nG1 Z5 F3000\nG0 X50 Y175 F20000 ; find a soft place to home\nG28 Z P0 T300; home z with low precision, permit 300deg temperature\nG29.2 S0 ; turn off ABL\n\nG0 X85 Y185 F10000 ;move to exposed steel surface and stop the nozzle\nG0 Z-1.01 F10000\nG91\n\nG2 I1 J0 X2 Y0 F2000.1\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\nG2 I1 J0 X2\nG2 I-0.75 J0 X-1.5\n\nG90\nG1 Z5 F30000\nG1 X25 Y175 F30000.1 ;Brush material\nG1 Z0.2 F30000.1\nG1 Y185\nG91\nG1 X-30 F30000\nG1 Y-2\nG1 X27\nG1 Y1.5\nG1 X-28\nG1 Y-2\nG1 X30\nG1 Y1.5\nG1 X-30\nG90\nM83\n\nG1 Z5\nG0 X55 Y175 F20000 ; find a soft place to home\nG28 Z P0 T300; home z with low precision, permit 300deg temperature\nG29.2 S0 ; turn off ABL\n\nG1 Z10\nG1 X85 Y185\nG1 Z-1.01\nG1 X95\nG1 X90\n\nM211 R; pop softend status\n\nM106 S0 ; turn off fan , too noisy\n;===== wipe nozzle end ================================\n\n\n;===== wait heatbed  ====================\nM1002 gcode_claim_action:54\nM104 S0\nM190 S[bed_temperature_initial_layer_single];set bed temp\nM109 S140\n\nG1 Z5 F3000\nG29.2 S1\nG1 X10 Y10 F20000\n\n;===== bed leveling ==================================\n;M1002 set_flag g29_before_print_flag=1\nM1002 judge_flag g29_before_print_flag\nM622 J1\n    M1002 gcode_claim_action : 1\n    G29 A1 X{first_layer_print_min[0]} Y{first_layer_print_min[1]} I{first_layer_print_size[0]} J{first_layer_print_size[1]}\n    M400\n    M500 ; save cali data\nM623\n;===== bed leveling end ================================\n\n;===== home after wipe mouth============================\nM1002 judge_flag g29_before_print_flag\nM622 J0\n\n    M1002 gcode_claim_action : 13\n    G28 T145\n\nM623\n\n;===== home after wipe mouth end =======================\n\nM975 S1 ; turn on vibration supression\n;===== nozzle load line ===============================\nM975 S1\nG90\nM83\nT1000\n\nG1 X-13.5 Y0 Z10 F10000\nG1 E1.2 F500\nM400\nM1002 set_filament_type:UNKNOWN\nM109 S{nozzle_temperature[initial_extruder]}\nM400\n\nM412 S1 ;    ===turn on  filament runout detection===\nM400 P10\n\nG392 S0 ;turn on clog detect\n\nM620.3 W1; === turn on filament tangle detection===\nM400 S2\n\nM1002 set_filament_type:{filament_type[initial_no_support_extruder]}\n;M1002 set_flag extrude_cali_flag=1\nM1002 judge_flag extrude_cali_flag\nM622 J1\n    M1002 gcode_claim_action : 8\n    \n    M400\n    M900 K0.0 L1000.0 M1.0\n    G90\n    M83\n    G0 X68 Y-4 F30000\n    G0 Z0.3 F18000 ;Move to start position\n    M400\n    G0 X88 E10  F{outer_wall_volumetric_speed/(24/20)    * 60}\n    G0 X93 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X98 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X103 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 X108 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\n    G0 X113 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\n    G0 Y0 Z0 F20000\n    M400\n    \n    G1 X-13.5 Y0 Z10 F10000\n    M400\n    \n    G1 E10 F{outer_wall_volumetric_speed/2.4*60}\n    M983 F{outer_wall_volumetric_speed/2.4} A0.3 H[nozzle_diameter]; cali dynamic extrusion compensation\n    M106 P1 S178\n    M400 S7\n    G1 X0 F18000\n    G1 X-13.5 F3000\n    G1 X0 F18000 ;wipe and shake\n    G1 X-13.5 F3000\n    G1 X0 F12000 ;wipe and shake\n    G1 X-13.5 F3000\n    M400\n    M106 P1 S0\n\n    M1002 judge_last_extrude_cali_success\n    M622 J0\n        M983 F{outer_wall_volumetric_speed/2.4} A0.3 H[nozzle_diameter]; cali dynamic extrusion compensation\n        M106 P1 S178\n        M400 S7\n        G1 X0 F18000\n        G1 X-13.5 F3000\n        G1 X0 F18000 ;wipe and shake\n        G1 X-13.5 F3000\n        G1 X0 F12000 ;wipe and shake\n        M400\n        M106 P1 S0\n    M623\n    \n    G1 X-13.5 F3000\n    M400\n    M984 A0.1 E1 S1 F{outer_wall_volumetric_speed/2.4} H[nozzle_diameter]\n    M106 P1 S178\n    M400 S7\n    G1 X0 F18000\n    G1 X-13.5 F3000\n    G1 X0 F18000 ;wipe and shake\n    G1 X-13.5 F3000\n    G1 X0 F12000 ;wipe and shake\n    G1 X-13.5 F3000\n    M400\n    M106 P1 S0\n\nM623 ; end of \"draw extrinsic para cali paint\"\n\n;===== extrude cali test ===============================\nM104 S{nozzle_temperature_initial_layer[initial_extruder]}\nG90\nM83\nG0 X68 Y-2.5 F30000\nG0 Z0.3 F18000 ;Move to start position\nG0 X88 E10  F{outer_wall_volumetric_speed/(24/20)    * 60}\nG0 X93 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\nG0 X98 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 X103 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\nG0 X108 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)     * 60}\nG0 X113 E.3742  F{outer_wall_volumetric_speed/(0.3*0.5)/4     * 60}\nG0 X115 Z0 F20000\nG0 Z5\nM400\n\n;========turn off light and wait extrude temperature =============\nM1002 gcode_claim_action : 0\n\nM400 ; wait all motion done before implement the emprical L parameters\n\n;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==\n;curr_bed_type={curr_bed_type}\n{if curr_bed_type==\"Textured PEI Plate\"}\nG29.1 Z{-0.02} ; for Textured PEI Plate\n{endif}\n\nM960 S1 P0 ; turn off laser\nM960 S2 P0 ; turn off laser\nM106 S0 ; turn off fan\nM106 P2 S0 ; turn off big fan\nM106 P3 S0 ; turn off chamber fan\n\nM975 S1 ; turn on mech mode supression\nG90\nM83\nT1000\n\nM211 X0 Y0 Z0 ;turn off soft endstop\nM1007 S1\n\n\n\n
; machine_switch_extruder_time = 0
; machine_unload_filament_time = 34
; master_extruder_id = 1
; max_bridge_length = 0
; max_layer_height = 0.28
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.08
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.76
; nozzle_temperature = 220
; nozzle_temperature_initial_layer = 220
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = stainless_steel
; nozzle_volume = 92
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 5000
; outer_wall_jerk = 9
; outer_wall_line_width = 0.42
; outer_wall_speed = 200
; overhang_1_4_speed = 0
; overhang_2_4_speed = 50
; overhang_3_4_speed = 30
; overhang_4_4_speed = 10
; overhang_fan_speed = 100
; overhang_fan_threshold = 50%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab A1 mini 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL A1M
; printable_area = 0x0,180x0,180x180,0x180
; printable_height = 180
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab A1 mini
; printer_notes = 
; printer_settings_id = Bambu Lab A1 mini 0.4 nozzle
; printer_structure = i3
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 1
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 3
; resolution = 0.012
; retract_before_wipe = 0%
; retract_length_toolchange = 2
; retract_lift_above = 0
; retract_lift_below = 179
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 1
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 0
; retraction_length = 0.8
; retraction_minimum_travel = 1
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 1
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.45
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.45
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 0
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 8
; slow_down_min_speed = 20
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 80
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 20%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.45
; sparse_infill_pattern = grid
; sparse_infill_speed = 270
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 45
; supertack_plate_temp_initial_layer = 45
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 2
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 2
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.15
; support_ironing_speed = 30
; support_line_width = 0.42
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 150
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = normal(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 45
; template_custom_gcode = 
; textured_plate_temp = 65
; textured_plate_temp_initial_layer = 65
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = ;===================== date: 20250206 =====================\n{if !spiral_mode && print_sequence != \"by object\"}\n; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer\n; SKIPPABLE_START\n; SKIPTYPE: timelapse\nM622.1 S1 ; for prev firmware, default turned on\nM1002 judge_flag timelapse_record_flag\nM622 J1\nG92 E0\nG1 Z{max_layer_z + 0.4}\nG1 X0 Y{first_layer_center_no_wipe_tower[1]} F18000 ; move to safe pos\nG1 X-13.0 F3000 ; move to safe pos\nM400\nM1004 S5 P1  ; external shutter\nM400 P300\nM971 S11 C11 O0\nG92 E0\nG1 X0 F18000\nM623\n\n; SKIPTYPE: head_wrap_detect\nM622.1 S1\nM1002 judge_flag g39_3rd_layer_detect_flag\nM622 J1\n    ; enable nozzle clog detect at 3rd layer\n    {if layer_num == 2}\n      M400\n      G90\n      M83\n      M204 S5000\n      G0 Z2 F4000\n      G0 X187 Y178 F20000\n      G39 S1 X187 Y178\n      G0 Z2 F4000\n    {endif}\n\n\n    M622.1 S1\n    M1002 judge_flag g39_detection_flag\n    M622 J1\n      {if !in_head_wrap_detect_zone}\n        M622.1 S0\n        M1002 judge_flag g39_mass_exceed_flag\n        M622 J1\n        {if layer_num > 2}\n            G392 S0\n            M400\n            G90\n            M83\n            M204 S5000\n            G0 Z{max_layer_z + 0.4} F4000\n            G39.3 S1\n            G0 Z{max_layer_z + 0.4} F4000\n            G392 S0\n          {endif}\n        M623\n    {endif}\n    M623\nM623\n; SKIPPABLE_END\n{endif}\n\n\n
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 5
; top_one_wall_type = all top
; top_shell_layers = 5
; top_shell_thickness = 1
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 2000
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.42
; top_surface_pattern = monotonicline
; top_surface_speed = 200
; top_z_overrides_xy_distance = 0
; travel_acceleration = 10000
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 700
; travel_speed_z = 0
; tree_support_branch_angle = 45
; tree_support_branch_diameter = 2
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab P1S 0.4 nozzle";"Bambu Lab P1P 0.4 nozzle";"Bambu Lab X1 0.4 nozzle";"Bambu Lab X1 Carbon 0.4 nozzle";"Bambu Lab X1E 0.4 nozzle";"Bambu Lab A1 0.4 nozzle";"Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = "0 0 0 0 0 0"
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = classic
; wall_loops = 3
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 1
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Auto Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R8
M201 X6000 Y6000 Z1500 E5000
M203 X500 Y500 Z30 E30
M204 P20000 R5000 T20000
M205 X9.00 Y9.00 Z5.00 E3.00
M106 S0
; FEATURE: Custom
;===== machine: A1 mini =========================
;===== date: 20260513 ==================

;===== start to heat heatbead&hotend==========
M1002 gcode_claim_action : 2
M1002 set_filament_type:PLA
M104 S170
M140 S65
G392 S0 ;turn off clog detect
M9833.2
;=====start printer sound ===================
M17
M400 S1
M1006 S1
M1006 A0 B0 L100 C37 D10 M100 E37 F10 N100
M1006 A0 B0 L100 C41 D10 M100 E41 F10 N100
M1006 A0 B0 L100 C44 D10 M100 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A43 B10 L100 C39 D10 M100 E46 F10 N100
M1006 A0 B0 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B0 L100 C39 D10 M100 E43 F10 N100
M1006 A0 B0 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B0 L100 C41 D10 M100 E41 F10 N100
M1006 A0 B0 L100 C44 D10 M100 E44 F10 N100
M1006 A0 B0 L100 C49 D10 M100 E49 F10 N100
M1006 A0 B0 L100 C0 D10 M100 E0 F10 N100
M1006 A44 B10 L100 C39 D10 M100 E48 F10 N100
M1006 A0 B0 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B0 L100 C39 D10 M100 E44 F10 N100
M1006 A0 B0 L100 C0 D10 M100 E0 F10 N100
M1006 A43 B10 L100 C39 D10 M100 E46 F10 N100
M1006 W
M18
;=====avoid end stop =================
G91
G380 S2 Z30 F1200
G380 S3 Z-20 F1200
G1 Z5 F1200
G90

;===== reset machine status =================
M204 S6000

M630 S0 P0
G91
M17 Z0.3 ; lower the z-motor current

G90
M17 X0.7 Y0.9 Z0.5 ; reset motor current to default
M960 S5 P1 ; turn on logo lamp
G90
M83
M220 S100 ;Reset Feedrate
M221 S100 ;Reset Flowrate
M73.2   R1.0 ;Reset left time magnitude
;====== cog noise reduction=================
M982.2 S1 ; turn on cog noise reduction

;===== prepare print temperature and material ==========
M400
M18
M109 S100 H170
M104 S170
M400
M17
M400
G28 X

M211 X0 Y0 Z0 ;turn off soft endstop ; turn off soft endstop to prevent protential logic problem

M975 S1 ; turn on

G1 X0.0 F30000
G1 X-13.5 F3000

M620 M ;enable remap
M620 S0A   ; switch material if AMS exist
    G392 S0 ;turn on clog detect
    M1002 gcode_claim_action : 4
    M400
    M1002 set_filament_type:UNKNOWN
    M109 S220

    M104 S220

    M400
    T0
    G1 X-13.5 F3000
    M400

    M620.1 E F299.339 T220
    M109 S220 ;set nozzle to common flush temp

    M106 P1 S0
    G92 E0
M73 P5 R8
    G1 E50 F200
    M400
    M1002 set_filament_type:PLA

    M104 S220

    G92 E0
    G1 E50 F299.339
    M400
    M106 P1 S178
    G92 E0
M73 P8 R7
    G1 E5 F299.339
    M109 S200 ; drop nozzle temp, make filament shink a bit
    M104 S180
    G92 E0
M73 P10 R7
    G1 E-0.5 F300

    G1 X0 F30000
    G1 X-13.5 F3000
    G1 X0 F30000 ;wipe and shake
    G1 X-13.5 F3000
M73 P11 R7
    G1 X0 F12000 ;wipe and shake
    G1 X0 F30000
    G1 X-13.5 F3000
    M109 S180
    G392 S0 ;turn off clog detect
M621 S0A

M400
M106 P1 S0
;===== prepare print temperature and material end =====


;===== mech mode fast check============================
M1002 gcode_claim_action : 3
G0 X25 Y175 F20000 ; find a soft place to home
;M104 S0
G28 Z P0 T300; home z with low precision,permit 300deg temperature
G29.2 S0 ; turn off ABL
M104 S170

; build plate detect
M1002 judge_flag build_plate_detect_flag
M622 S1
  G39.4
  M400
M623

G1 Z5 F3000
G1 X90 Y-1 F30000
M400 P200
M970.3 Q1 A7 K0 O2
M974 Q1 S2 P0

G1 X90 Y0 Z5 F30000
M400 P200
M970 Q0 A10 B50 C90 H15 K0 M20 O3
M974 Q0 S2 P0

M975 S1
G1 F30000
G1 X-1 Y10
G28 X ; re-home XY

;===== wipe nozzle ===============================
M1002 gcode_claim_action : 14
M975 S1

M104 S170 ; set temp down to heatbed acceptable
M106 S255 ; turn on fan (G28 has turn off fan)
M211 S; push soft endstop status
M211 X0 Y0 Z0 ;turn off Z axis endstop

M83
G1 E-1 F500
G90
M83

M109 S170
M104 S140
G0 X90 Y-4 F30000
G380 S3 Z-5 F1200
M73 P62 R3
G1 Z2 F1200
G1 X91 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X92 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X93 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X94 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X95 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X96 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X97 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X98 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X99 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X99 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X99 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X99 F10000
G380 S3 Z-5 F1200
G1 Z2 F1200
G1 X99 F10000
G380 S3 Z-5 F1200

G1 Z5 F30000
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
G1 X25 Y175 F30000.1 ;Brush material
G1 Z0.2 F30000.1
G1 Y185
G91
G1 X-30 F30000
G1 Y-2
G1 X27
G1 Y1.5
G1 X-28
G1 Y-2
G1 X30
G1 Y1.5
G1 X-30
G90
M83

G1 Z5 F3000
G0 X50 Y175 F20000 ; find a soft place to home
G28 Z P0 T300; home z with low precision, permit 300deg temperature
G29.2 S0 ; turn off ABL

G0 X85 Y185 F10000 ;move to exposed steel surface and stop the nozzle
G0 Z-1.01 F10000
G91

G2 I1 J0 X2 Y0 F2000.1
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
M73 P63 R3
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5
G2 I1 J0 X2
G2 I-0.75 J0 X-1.5

G90
G1 Z5 F30000
G1 X25 Y175 F30000.1 ;Brush material
G1 Z0.2 F30000.1
G1 Y185
G91
G1 X-30 F30000
G1 Y-2
G1 X27
G1 Y1.5
G1 X-28
G1 Y-2
G1 X30
G1 Y1.5
G1 X-30
G90
M83

G1 Z5
G0 X55 Y175 F20000 ; find a soft place to home
G28 Z P0 T300; home z with low precision, permit 300deg temperature
G29.2 S0 ; turn off ABL

G1 Z10
G1 X85 Y185
G1 Z-1.01
G1 X95
G1 X90

M211 R; pop softend status

M106 S0 ; turn off fan , too noisy
;===== wipe nozzle end ================================


;===== wait heatbed  ====================
M1002 gcode_claim_action:54
M104 S0
M190 S65;set bed temp
M109 S140

G1 Z5 F3000
G29.2 S1
G1 X10 Y10 F20000

;===== bed leveling ==================================
;M1002 set_flag g29_before_print_flag=1
M1002 judge_flag g29_before_print_flag
M622 J1
    M1002 gcode_claim_action : 1
    G29 A1 X75.3293 Y75.3293 I19.3414 J17.3414
    M400
    M500 ; save cali data
M623
;===== bed leveling end ================================

;===== home after wipe mouth============================
M1002 judge_flag g29_before_print_flag
M622 J0

    M1002 gcode_claim_action : 13
    G28 T145

M623

;===== home after wipe mouth end =======================

M975 S1 ; turn on vibration supression
;===== nozzle load line ===============================
M975 S1
G90
M83
T1000

G1 X-13.5 Y0 Z10 F10000
G1 E1.2 F500
M400
M1002 set_filament_type:UNKNOWN
M109 S220
M400

M412 S1 ;    ===turn on  filament runout detection===
M400 P10

G392 S0 ;turn on clog detect

M620.3 W1; === turn on filament tangle detection===
M400 S2

M1002 set_filament_type:PLA
;M1002 set_flag extrude_cali_flag=1
M1002 judge_flag extrude_cali_flag
M622 J1
    M1002 gcode_claim_action : 8
    
    M400
    M900 K0.0 L1000.0 M1.0
    G90
    M83
    G0 X68 Y-4 F30000
    G0 Z0.3 F18000 ;Move to start position
    M400
    G0 X88 E10  F720
    G0 X93 E.3742  F1200
    G0 X98 E.3742  F4800
    G0 X103 E.3742  F1200
    G0 X108 E.3742  F4800
    G0 X113 E.3742  F1200
    G0 Y0 Z0 F20000
    M400
    
    G1 X-13.5 Y0 Z10 F10000
    M400
    
    G1 E10 F300
    M983 F5 A0.3 H0.4; cali dynamic extrusion compensation
    M106 P1 S178
    M400 S7
    G1 X0 F18000
    G1 X-13.5 F3000
    G1 X0 F18000 ;wipe and shake
    G1 X-13.5 F3000
    G1 X0 F12000 ;wipe and shake
    G1 X-13.5 F3000
    M400
    M106 P1 S0

    M1002 judge_last_extrude_cali_success
    M622 J0
        M983 F5 A0.3 H0.4; cali dynamic extrusion compensation
        M106 P1 S178
        M400 S7
        G1 X0 F18000
        G1 X-13.5 F3000
M73 P64 R3
        G1 X0 F18000 ;wipe and shake
        G1 X-13.5 F3000
        G1 X0 F12000 ;wipe and shake
        M400
        M106 P1 S0
    M623
    
M73 P65 R2
    G1 X-13.5 F3000
    M400
    M984 A0.1 E1 S1 F5 H0.4
    M106 P1 S178
    M400 S7
    G1 X0 F18000
M73 P66 R2
    G1 X-13.5 F3000
    G1 X0 F18000 ;wipe and shake
    G1 X-13.5 F3000
    G1 X0 F12000 ;wipe and shake
    G1 X-13.5 F3000
    M400
    M106 P1 S0

M623 ; end of "draw extrinsic para cali paint"

;===== extrude cali test ===============================
M104 S220
G90
M83
G0 X68 Y-2.5 F30000
G0 Z0.3 F18000 ;Move to start position
G0 X88 E10  F720
G0 X93 E.3742  F1200
G0 X98 E.3742  F4800
G0 X103 E.3742  F1200
G0 X108 E.3742  F4800
G0 X113 E.3742  F1200
G0 X115 Z0 F20000
G0 Z5
M400

;========turn off light and wait extrude temperature =============
M1002 gcode_claim_action : 0

M400 ; wait all motion done before implement the emprical L parameters

;===== for Textured PEI Plate , lower the nozzle as the nozzle was touching topmost of the texture when homing ==
;curr_bed_type=Textured PEI Plate

G29.1 Z-0.02 ; for Textured PEI Plate


M960 S1 P0 ; turn off laser
M960 S2 P0 ; turn off laser
M106 S0 ; turn off fan
M106 P2 S0 ; turn off big fan
M106 P3 S0 ; turn off chamber fan

M975 S1 ; turn on mech mode supression
G90
M83
T1000

M211 X0 Y0 Z0 ;turn off soft endstop
M1007 S1



; MACHINE_START_GCODE_END
; filament start gcode
M106 P3 S255
;Prevent PLA from jamming


;VT0 H-1
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
G1 E-.8 F1800
; layer num/total_layer_count: 1/14
; update layer progress
M73 L1
M991 S0 P0 ;notify layer change
M106 S0
; OBJECT_ID: 15
G1 X76.926 Y76.797 F42000
M204 S6000
G1 Z.4
M73 P67 R2
G1 Z.2
M73 P68 R2
G1 E.8 F1800
; FEATURE: Brim
; LINE_WIDTH: 0.5
G1 F3000
M204 S500
G1 X77.419 Y76.386 E.0239
G1 X77.964 Y76.053 E.0238
G1 X78.75 Y75.742 E.03148
G1 X79.43 Y75.596 E.02589
M73 P70 R2
G1 X80.008 Y75.558 E.02157
G1 X89.992 Y75.558 E.37187
G1 X90.64 Y75.606 E.02422
G1 X91.263 Y75.746 E.02377
G1 X92.106 Y76.103 E.0341
G1 X92.724 Y76.5 E.02737
G1 X93.203 Y76.926 E.02386
G1 X93.614 Y77.419 E.0239
G1 X93.947 Y77.964 E.0238
G1 X94.258 Y78.75 E.03148
G1 X94.404 Y79.43 E.02589
G1 X94.442 Y80.008 E.02157
G1 X94.442 Y87.991 E.29737
G1 X94.394 Y88.64 E.02422
G1 X94.254 Y89.263 E.02377
G1 X93.897 Y90.106 E.0341
G1 X93.5 Y90.724 E.02737
G1 X93.074 Y91.203 E.02386
G1 X92.581 Y91.614 E.0239
M73 P71 R2
G1 X92.036 Y91.947 E.02378
G1 X91.198 Y92.273 E.03351
G1 X90.571 Y92.404 E.02386
G1 X89.992 Y92.442 E.0216
G1 X80.009 Y92.442 E.37186
G1 X79.36 Y92.394 E.02422
G1 X78.737 Y92.254 E.02377
G1 X77.894 Y91.897 E.0341
G1 X77.276 Y91.5 E.02737
G1 X76.797 Y91.074 E.02386
G1 X76.386 Y90.581 E.0239
G1 X76.053 Y90.036 E.02378
G1 X75.727 Y89.198 E.03351
G1 X75.596 Y88.571 E.02386
G1 X75.558 Y87.992 E.02159
G1 X75.558 Y80.008 E.29738
G1 X75.606 Y79.36 E.02422
G1 X75.746 Y78.737 E.02377
G1 X76.103 Y77.894 E.0341
G1 X76.5 Y77.276 E.02737
G1 X76.886 Y76.842 E.02163
M204 S6000
G1 X77.228 Y77.148 F42000
G1 F3000
M204 S500
G1 X77.253 Y77.12 E.00139
G1 X77.678 Y76.765 E.02062
G1 X78.159 Y76.47 E.02102
G1 X78.873 Y76.185 E.02862
G1 X79.503 Y76.049 E.02403
G1 X80.027 Y76.015 E.01956
G1 X89.98 Y76.015 E.37069
G1 X90.582 Y76.061 E.02251
G1 X91.133 Y76.188 E.02105
G1 X91.881 Y76.505 E.03024
G1 X92.438 Y76.86 E.02461
G1 X92.866 Y77.238 E.02128
G1 X93.247 Y77.694 E.02213
G1 X93.541 Y78.18 E.02114
G1 X93.821 Y78.894 E.02859
G1 X93.948 Y79.483 E.02245
G1 X93.985 Y80.027 E.02031
G1 X93.985 Y87.98 E.29619
G1 X93.939 Y88.582 E.02252
G1 X93.812 Y89.133 E.02105
G1 X93.495 Y89.881 E.03024
G1 X93.127 Y90.455 E.02541
G1 X92.747 Y90.88 E.02123
G1 X92.322 Y91.235 E.02062
G1 X91.822 Y91.54 E.02183
G1 X91.056 Y91.835 E.03056
G1 X90.518 Y91.948 E.02048
G1 X89.982 Y91.985 E.02003
G1 X80.02 Y91.985 E.37102
G1 X79.418 Y91.939 E.02252
G1 X78.867 Y91.812 E.02105
G1 X78.119 Y91.495 E.03024
G1 X77.545 Y91.127 E.02541
G1 X77.12 Y90.747 E.02123
G1 X76.765 Y90.322 E.02062
G1 X76.46 Y89.822 E.02183
G1 X76.165 Y89.056 E.03056
G1 X76.052 Y88.518 E.02048
G1 X76.015 Y87.982 E.02003
G1 X76.015 Y80.03 E.29616
G1 X76.058 Y79.438 E.02214
G1 X76.188 Y78.867 E.02181
G1 X76.505 Y78.119 E.03024
G1 X76.873 Y77.545 E.02541
G1 X77.188 Y77.192 E.0176
M204 S6000
G1 X77.528 Y77.499 F42000
G1 F3000
M204 S500
G1 X77.579 Y77.443 E.00281
G1 X77.953 Y77.132 E.01814
G1 X78.354 Y76.886 E.01752
G1 X78.996 Y76.628 E.02574
G1 X79.577 Y76.503 E.02214
G1 X80.047 Y76.472 E.01755
G1 X89.957 Y76.472 E.36912
G1 X90.503 Y76.514 E.0204
G1 X91.003 Y76.629 E.01911
G1 X91.657 Y76.906 E.02646
G1 X92.17 Y77.233 E.02266
G1 X92.544 Y77.565 E.01863
G1 X92.867 Y77.952 E.01877
G1 X93.123 Y78.373 E.01835
G1 X93.378 Y79.016 E.02577
G1 X93.492 Y79.538 E.01988
G1 X93.528 Y80.048 E.01904
G1 X93.527 Y87.967 E.29498
G1 X93.486 Y88.503 E.02001
G1 X93.371 Y89.003 E.01911
G1 X93.094 Y89.656 E.02643
G1 X92.755 Y90.186 E.02343
G1 X92.436 Y90.543 E.01785
G1 X92.064 Y90.856 E.01809
G1 X91.607 Y91.132 E.01987
G1 X90.915 Y91.398 E.02761
G1 X90.446 Y91.495 E.01785
G1 X89.971 Y91.527 E.01775
G1 X80.033 Y91.527 E.37015
G1 X79.497 Y91.486 E.02001
G1 X78.997 Y91.371 E.01911
G1 X78.344 Y91.094 E.02643
G1 X77.814 Y90.755 E.02343
G1 X77.457 Y90.436 E.01785
G1 X77.144 Y90.064 E.01809
G1 X76.868 Y89.607 E.01987
G1 X76.602 Y88.915 E.02761
G1 X76.505 Y88.446 E.01785
G1 X76.473 Y87.971 E.01775
G1 X76.472 Y80.052 E.29494
G1 X76.511 Y79.516 E.02004
G1 X76.629 Y78.996 E.01984
G1 X76.906 Y78.344 E.0264
G1 X77.245 Y77.814 E.02343
G1 X77.488 Y77.544 E.01354
M204 S6000
G1 X77.83 Y77.848 F42000
G1 F3000
M204 S500
G1 X77.89 Y77.781 E.00336
G1 X78.213 Y77.511 E.01569
G1 X78.571 Y77.291 E.01566
G1 X79.119 Y77.071 E.022
G1 X79.65 Y76.956 E.02024
G1 X80.066 Y76.929 E.01552
G1 X89.934 Y76.929 E.36756
G1 X90.424 Y76.966 E.01827
G1 X90.872 Y77.07 E.01716
G1 X91.433 Y77.308 E.02269
G1 X91.902 Y77.606 E.0207
G1 X92.221 Y77.892 E.01596
G1 X92.488 Y78.211 E.01549
G1 X92.707 Y78.568 E.01557
G1 X92.936 Y79.14 E.02295
G1 X93.036 Y79.593 E.0173
G1 X93.071 Y80.068 E.01775
G1 X93.07 Y87.945 E.29335
G1 X93.034 Y88.424 E.01789
G1 X92.93 Y88.872 E.01716
G1 X92.693 Y89.432 E.02263
G1 X92.396 Y89.899 E.02063
G1 X92.123 Y90.207 E.0153
G1 X91.787 Y90.489 E.01632
G1 X91.394 Y90.725 E.0171
G1 X90.797 Y90.954 E.02381
G1 X90.375 Y91.042 E.01606
G1 X89.95 Y91.07 E.01585
G1 X80.055 Y91.07 E.36854
G1 X79.576 Y91.034 E.01789
G1 X79.128 Y90.93 E.01716
G1 X78.548 Y90.682 E.02349
G1 X78.101 Y90.396 E.01977
G1 X77.793 Y90.123 E.0153
G1 X77.511 Y89.787 E.01632
G1 X77.275 Y89.394 E.0171
G1 X77.046 Y88.797 E.02381
G1 X76.958 Y88.375 E.01606
M73 P72 R2
G1 X76.93 Y87.95 E.01585
G1 X76.929 Y80.074 E.29337
G1 X76.967 Y79.573 E.01869
G1 X77.071 Y79.126 E.0171
G1 X77.318 Y78.548 E.02343
G1 X77.604 Y78.101 E.01974
G1 X77.79 Y77.893 E.0104
M204 S6000
G1 X78.132 Y78.196 F42000
G1 F3000
M204 S500
G1 X78.202 Y78.118 E.00389
G1 X78.472 Y77.89 E.01318
G1 X78.768 Y77.707 E.01293
G1 X79.243 Y77.514 E.01913
G1 X79.704 Y77.412 E.01756
G1 X80.076 Y77.386 E.01391
G1 X89.912 Y77.386 E.36635
G1 X90.344 Y77.419 E.01613
G1 X90.741 Y77.511 E.0152
G1 X91.21 Y77.709 E.01894
G1 X91.634 Y77.979 E.01871
G1 X91.898 Y78.218 E.01328
G1 X92.109 Y78.471 E.01229
G1 X92.291 Y78.764 E.01281
G1 X92.493 Y79.265 E.02014
G1 X92.581 Y79.65 E.0147
G1 X92.614 Y80.09 E.01645
G1 X92.613 Y87.932 E.2921
G1 X92.578 Y88.364 E.01614
G1 X92.489 Y88.741 E.01443
G1 X92.281 Y89.228 E.01973
G1 X92.035 Y89.614 E.01703
G1 X91.81 Y89.871 E.01271
G1 X91.512 Y90.121 E.0145
G1 X91.182 Y90.317 E.0143
G1 X90.657 Y90.516 E.02091
G1 X90.303 Y90.588 E.01344
G1 X89.939 Y90.613 E.01359
G1 X80.078 Y90.613 E.3673
G1 X79.656 Y90.582 E.01575
G1 X79.259 Y90.489 E.01519
G1 X78.753 Y90.27 E.02055
G1 X78.386 Y90.036 E.0162
G1 X78.129 Y89.81 E.01274
G1 X77.879 Y89.512 E.0145
G1 X77.683 Y89.182 E.0143
G1 X77.49 Y88.678 E.02009
G1 X77.412 Y88.303 E.01427
G1 X77.387 Y87.93 E.01393
G1 X77.386 Y80.096 E.29179
G1 X77.419 Y79.653 E.01654
G1 X77.512 Y79.258 E.01513
G1 X77.73 Y78.753 E.0205
G1 X77.963 Y78.388 E.01614
G1 X78.093 Y78.241 E.00729
M204 S6000
G1 X78.451 Y78.555 F42000
G1 F3000
M204 S500
G1 X78.566 Y78.424 E.00648
G1 X78.934 Y78.15 E.0171
G1 X79.277 Y77.986 E.01413
G1 X79.649 Y77.884 E.01439
G1 X80.035 Y77.843 E.01444
G1 X89.959 Y77.843 E.36965
G1 X90.407 Y77.899 E.0168
G1 X90.858 Y78.04 E.0176
G1 X91.045 Y78.142 E.00793
G1 X91.436 Y78.429 E.01808
G1 X91.531 Y78.519 E.00487
G1 X91.76 Y78.796 E.01337
G1 X91.964 Y79.161 E.01557
G1 X92.094 Y79.548 E.01522
G1 X92.153 Y79.968 E.0158
G1 X92.154 Y88.026 E.30012
G1 X92.09 Y88.458 E.01625
G1 X91.92 Y88.938 E.01897
G1 X91.76 Y89.205 E.01159
G1 X91.48 Y89.533 E.01607
G1 X91.204 Y89.76 E.01331
G1 X90.839 Y89.964 E.01556
G1 X90.453 Y90.094 E.0152
G1 X89.964 Y90.157 E.01836
G1 X80.032 Y90.157 E.36992
G1 X79.648 Y90.113 E.01438
G1 X79.166 Y89.966 E.01878
G1 X78.794 Y89.759 E.01588
G1 X78.467 Y89.48 E.01598
G1 X78.24 Y89.204 E.01332
G1 X78.036 Y88.839 E.01556
G1 X77.906 Y88.452 E.01523
G1 X77.847 Y88.032 E.01579
G1 X77.859 Y79.855 E.30457
G1 X77.953 Y79.378 E.01812
G1 X78.101 Y79.017 E.0145
G1 X78.251 Y78.784 E.01035
G1 X78.412 Y78.6 E.00908
M204 S6000
G1 X78.758 Y78.888 F42000
G1 F3000
M204 S500
G1 X78.839 Y78.791 E.00469
G1 X79.131 Y78.562 E.01382
G1 X79.398 Y78.427 E.01116
G1 X79.692 Y78.339 E.01143
G1 X80.027 Y78.3 E.01256
G1 X89.968 Y78.3 E.37024
G1 X90.355 Y78.353 E.01457
G1 X90.645 Y78.443 E.01128
G1 X90.767 Y78.505 E.00513
G1 X91.173 Y78.803 E.01873
G1 X91.415 Y79.096 E.01415
G1 X91.563 Y79.38 E.01194
G1 X91.661 Y79.693 E.01221
G1 X91.7 Y80.027 E.01254
G1 X91.697 Y88.036 E.29828
G1 X91.659 Y88.305 E.01014
G1 X91.529 Y88.702 E.01557
G1 X91.409 Y88.912 E.00896
G1 X91.199 Y89.172 E.01248
G1 X90.904 Y89.415 E.01422
G1 X90.62 Y89.563 E.01195
G1 X90.307 Y89.661 E.01221
G1 X89.973 Y89.7 E.01254
G1 X80.024 Y89.7 E.37054
G1 X79.694 Y89.659 E.01241
G1 X79.298 Y89.529 E.01553
G1 X79.088 Y89.409 E.00896
G1 X78.828 Y89.199 E.01248
G1 X78.585 Y88.904 E.01422
G1 X78.437 Y88.62 E.01195
G1 X78.339 Y88.307 E.01221
G1 X78.3 Y87.973 E.01253
G1 X78.307 Y79.945 E.29902
G1 X78.377 Y79.548 E.01499
G1 X78.484 Y79.266 E.01124
G1 X78.599 Y79.08 E.00812
G1 X78.72 Y78.934 E.00709
M204 S6000
G1 X79.072 Y79.226 F42000
G1 F3000
M204 S500
G1 X79.196 Y79.076 E.00726
G1 X79.403 Y78.929 E.00943
G1 X79.6 Y78.837 E.0081
G1 X79.742 Y78.794 E.00552
G1 X80.019 Y78.757 E.01043
G1 X89.977 Y78.757 E.37088
G1 X90.295 Y78.806 E.01198
G1 X90.503 Y78.878 E.00819
G1 X90.827 Y79.101 E.01467
G1 X91.003 Y79.295 E.00976
G1 X91.164 Y79.603 E.01293
G1 X91.206 Y79.742 E.0054
G1 X91.243 Y80.019 E.01044
G1 X91.243 Y87.984 E.29666
G1 X91.224 Y88.166 E.00679
G1 X91.13 Y88.48 E.01222
G1 X91.051 Y88.629 E.00628
G1 X90.899 Y88.828 E.00934
G1 X90.705 Y89.003 E.00972
G1 X90.397 Y89.164 E.01294
G1 X90.258 Y89.206 E.0054
G1 X89.981 Y89.243 E.01044
G1 X80.016 Y89.243 E.37115
G1 X79.834 Y89.224 E.00679
G1 X79.52 Y89.13 E.01222
G1 X79.371 Y89.051 E.00628
G1 X79.172 Y88.899 E.00934
G1 X78.997 Y88.705 E.00972
G1 X78.836 Y88.397 E.01294
G1 X78.794 Y88.258 E.0054
G1 X78.757 Y87.981 E.01043
G1 X78.757 Y80.023 E.29639
G1 X78.806 Y79.705 E.01198
G1 X78.878 Y79.497 E.00819
G1 X78.944 Y79.379 E.00504
G1 X79.034 Y79.272 E.00521
M204 S6000
G1 X79.393 Y79.544 F42000
G1 F3000
M204 S500
G1 X79.473 Y79.439 E.00493
G1 X79.586 Y79.348 E.00541
G1 X79.803 Y79.246 E.00893
G1 X80.011 Y79.214 E.00782
G1 X89.988 Y79.214 E.37161
G1 X90.221 Y79.257 E.00884
G1 X90.339 Y79.304 E.00475
M73 P73 R2
G1 X90.561 Y79.473 E.01037
G1 X90.652 Y79.586 E.00541
G1 X90.754 Y79.803 E.00892
G1 X90.786 Y80.011 E.00782
G1 X90.786 Y87.991 E.29725
G1 X90.77 Y88.118 E.00475
G1 X90.694 Y88.343 E.00884
G1 X90.527 Y88.561 E.01023
G1 X90.414 Y88.652 E.00541
G1 X90.197 Y88.754 E.00892
G1 X89.989 Y88.786 E.00782
G1 X80.009 Y88.786 E.37174
G1 X79.882 Y88.77 E.00475
G1 X79.657 Y88.694 E.00884
G1 X79.439 Y88.527 E.01023
G1 X79.348 Y88.414 E.00541
G1 X79.246 Y88.197 E.00893
G1 X79.214 Y87.989 E.00782
G1 X79.214 Y80.012 E.29711
G1 X79.257 Y79.779 E.00884
G1 X79.304 Y79.661 E.00475
G1 X79.356 Y79.592 E.0032
M204 S6000
G1 X79.745 Y79.807 F42000
G1 F3000
M204 S500
G1 X79.747 Y79.805 E.00011
G1 X79.884 Y79.696 E.00651
G1 X80 Y79.671 E.00442
G1 X90 Y79.671 E.37246
G1 X90.111 Y79.7 E.00426
G1 X90.195 Y79.747 E.00361
G1 X90.304 Y79.884 E.00651
G1 X90.329 Y80 E.00442
G1 X90.329 Y88 E.29797
G1 X90.3 Y88.111 E.00426
G1 X90.253 Y88.195 E.00361
G1 X90.116 Y88.304 E.00651
G1 X90 Y88.329 E.00442
G1 X80 Y88.329 E.37246
G1 X79.889 Y88.3 E.00426
G1 X79.805 Y88.253 E.00361
G1 X79.696 Y88.116 E.00651
G1 X79.671 Y88 E.00442
G1 X79.671 Y80 E.29797
G1 X79.7 Y79.889 E.00426
G1 X79.716 Y79.86 E.00126
; WIPE_START
G1 X79.747 Y79.805 E-.02396
G1 X79.884 Y79.696 E-.06647
G1 X80 Y79.671 E-.04514
G1 X81.643 Y79.671 E-.62444
; WIPE_END
G1 E-.04 F1800
M204 S6000
G1 X87.05 Y85.059 Z.6 F42000
G1 X89.75 Y87.75 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Outer wall
G1 F3000
M204 S500
G1 X80.25 Y87.75 E.35384
G1 X80.25 Y80.25 E.27935
G1 X89.75 Y80.25 E.35384
G1 X89.75 Y87.69 E.27711
M204 S6000
G1 X89.293 Y87.293 F42000
; FEATURE: Inner wall
G1 F3000
M204 S500
G1 X80.707 Y87.293 E.31979
G1 X80.707 Y80.707 E.2453
G1 X89.293 Y80.707 E.31979
G1 X89.293 Y87.233 E.24306
M204 S6000
G1 X88.836 Y86.836 F42000
G1 F3000
M204 S500
G1 X81.164 Y86.836 E.28574
G1 X81.164 Y81.164 E.21125
G1 X88.836 Y81.164 E.28574
G1 X88.836 Y86.776 E.20902
; WIPE_START
G1 X86.836 Y86.792 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S6000
G17
G3 Z.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z0.6
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X88.653 Y82.304 F42000
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.51569
G1 F6300
M204 S500
G1 X87.901 Y81.553 E.04095
G1 X87.233 Y81.553 E.02576
G1 X88.447 Y82.767 E.06617
G1 X88.447 Y83.436 E.02576
G1 X86.564 Y81.553 E.10259
G1 X85.896 Y81.553 E.02576
G1 X88.447 Y84.104 E.13902
G1 X88.447 Y84.773 E.02576
G1 X85.227 Y81.553 E.17545
G1 X84.558 Y81.553 E.02576
G1 X88.447 Y85.442 E.21187
G1 X88.447 Y86.11 E.02576
G1 X83.89 Y81.553 E.2483
G1 X83.221 Y81.553 E.02576
G1 X88.116 Y86.447 E.26667
G1 X87.447 Y86.447 E.02576
G1 X82.553 Y81.553 E.26667
G1 X81.884 Y81.553 E.02576
G1 X86.779 Y86.447 E.26667
M73 P74 R2
G1 X86.11 Y86.447 E.02576
G1 X81.553 Y81.89 E.24831
G1 X81.553 Y82.558 E.02576
G1 X85.442 Y86.447 E.21188
G1 X84.773 Y86.447 E.02576
G1 X81.553 Y83.227 E.17545
G1 X81.553 Y83.896 E.02576
G1 X84.104 Y86.447 E.13903
G1 X83.436 Y86.447 E.02576
G1 X81.553 Y84.564 E.1026
G1 X81.553 Y85.233 E.02576
G1 X82.767 Y86.447 E.06617
G1 X82.099 Y86.447 E.02576
G1 X81.347 Y85.696 E.04095
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F6300
G1 X82.099 Y86.447 E-.40394
G1 X82.767 Y86.447 E-.25407
G1 X82.577 Y86.258 E-.102
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 2/14
; update layer progress
M73 L2
M991 S0 P1 ;notify layer change
M106 S201.45
; open powerlost recovery
M1003 S1
; OBJECT_ID: 15
M204 S10000
G17
G3 Z.6 I-.138 J1.209 P1  F42000
G1 X88.991 Y86.991 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1715
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1715
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1715
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z0.8
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X86.262 Y84 F42000
M73 P75 R2
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56784
G1 F1715
M204 S6000
G1 X86.262 Y83.738 E.01123
G1 X83.738 Y83.738 E.108
G1 X83.738 Y84.262 E.02245
G1 X86.262 Y84.262 E.108
G1 X86.262 Y84.06 E.00866
M204 S10000
G1 X86.713 Y84 F42000
; LINE_WIDTH: 0.41999
G1 F1715
M204 S6000
G1 X86.713 Y83.287 E.02192
G1 X83.287 Y83.287 E.1053
G1 X83.287 Y84.713 E.04384
G1 X86.713 Y84.713 E.1053
G1 X86.713 Y84.06 E.02008
M204 S10000
G1 X87.091 Y84 F42000
G1 F1715
M204 S6000
G1 X87.091 Y82.909 E.03351
G1 X82.909 Y82.909 E.12847
G1 X82.909 Y85.091 E.06702
G1 X87.091 Y85.091 E.12847
G1 X87.091 Y84.06 E.03166
M204 S10000
G1 X87.468 Y84 F42000
G1 F1715
M204 S6000
G1 X87.468 Y82.532 E.04509
G1 X82.532 Y82.532 E.15164
G1 X82.532 Y85.468 E.09019
G1 X87.468 Y85.468 E.15164
G1 X87.468 Y84.06 E.04325
M204 S10000
G1 X87.845 Y84 F42000
G1 F1715
M204 S6000
G1 X87.845 Y82.155 E.05668
G1 X82.155 Y82.155 E.17481
G1 X82.155 Y85.845 E.11336
G1 X87.845 Y85.845 E.17481
G1 X87.845 Y84.06 E.05484
M204 S10000
G1 X88.222 Y84 F42000
G1 F1715
M204 S6000
G1 X88.222 Y81.778 E.06827
G1 X81.778 Y81.778 E.19799
G1 X81.778 Y86.222 E.13653
G1 X88.222 Y86.222 E.19799
M73 P76 R2
G1 X88.222 Y84.06 E.06642
M204 S10000
G1 X88.599 Y84 F42000
G1 F1715
M204 S6000
G1 X88.599 Y81.401 E.07985
G1 X81.401 Y81.401 E.22116
G1 X81.401 Y86.599 E.1597
G1 X88.599 Y86.599 E.22116
G1 X88.599 Y84.06 E.07801
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9547.299
G1 X88.599 Y86.06 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 3/14
; update layer progress
M73 L3
M991 S0 P2 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z.8 I-1.122 J.472 P1  F42000
G1 X88.991 Y86.991 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1711
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1711
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1711
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1
M73 P76 R1
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    
      M400
      G90
      M83
      M204 S5000
      G0 Z2 F4000
      G0 X187 Y178 F20000
      G39 S1 X187 Y178
      G0 Z2 F4000
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
        M623
    
    M623
M623
; SKIPPABLE_END




G1 Z1.000
G1 X86.262 Y84 F42000
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56784
G1 F1711
M204 S6000
G1 X86.262 Y83.738 E.01123
G1 X83.738 Y83.738 E.108
G1 X83.738 Y84.262 E.02245
G1 X86.262 Y84.262 E.108
G1 X86.262 Y84.06 E.00866
M204 S10000
G1 X86.713 Y84 F42000
; LINE_WIDTH: 0.41999
G1 F1711
M204 S6000
G1 X86.713 Y83.287 E.02192
G1 X83.287 Y83.287 E.1053
M73 P77 R1
G1 X83.287 Y84.713 E.04384
G1 X86.713 Y84.713 E.1053
G1 X86.713 Y84.06 E.02008
M204 S10000
G1 X87.091 Y84 F42000
G1 F1711
M204 S6000
G1 X87.091 Y82.909 E.03351
G1 X82.909 Y82.909 E.12847
G1 X82.909 Y85.091 E.06702
G1 X87.091 Y85.091 E.12847
G1 X87.091 Y84.06 E.03166
M204 S10000
G1 X87.468 Y84 F42000
G1 F1711
M204 S6000
G1 X87.468 Y82.532 E.04509
G1 X82.532 Y82.532 E.15164
G1 X82.532 Y85.468 E.09019
G1 X87.468 Y85.468 E.15164
G1 X87.468 Y84.06 E.04325
M204 S10000
G1 X87.845 Y84 F42000
G1 F1711
M204 S6000
G1 X87.845 Y82.155 E.05668
G1 X82.155 Y82.155 E.17481
G1 X82.155 Y85.845 E.11336
G1 X87.845 Y85.845 E.17481
G1 X87.845 Y84.06 E.05484
M204 S10000
G1 X88.222 Y84 F42000
G1 F1711
M204 S6000
G1 X88.222 Y81.778 E.06827
G1 X81.778 Y81.778 E.19799
G1 X81.778 Y86.222 E.13653
G1 X88.222 Y86.222 E.19799
G1 X88.222 Y84.06 E.06642
M204 S10000
G1 X88.599 Y84 F42000
G1 F1711
M204 S6000
G1 X88.599 Y81.401 E.07985
G1 X81.401 Y81.401 E.22116
G1 X81.401 Y86.599 E.1597
G1 X88.599 Y86.599 E.22116
G1 X88.599 Y84.06 E.07801
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9547.299
G1 X88.599 Y86.06 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 4/14
; update layer progress
M73 L4
M991 S0 P3 ;notify layer change
M106 S204
; OBJECT_ID: 15
M204 S10000
G17
M73 P78 R1
G3 Z1 I-1.122 J.472 P1  F42000
G1 X88.991 Y86.991 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.2
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.2 F4000
            G39.3 S1
            G0 Z1.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X81.357 Y83.514 F42000
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.357 Y81.886 E.05401
G1 X81.886 Y81.357 E.02478
G1 X82.357 Y81.357 E.01565
G1 X87.643 Y86.643 E.24794
G1 X88.114 Y86.643 E.01565
G1 X88.643 Y86.114 E.02478
G1 X88.643 Y81.886 E.14027
G1 X88.114 Y81.357 E.02478
G1 X87.643 Y81.357 E.01565
G1 X82.357 Y86.643 E.24794
G1 X81.886 Y86.643 E.01565
G1 X81.357 Y86.114 E.02478
G1 X81.357 Y84.486 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
; WIPE_START
M73 P79 R1
G1 F8843.478
G1 X81.357 Y86.114 E-.61876
G1 X81.62 Y86.377 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 5/14
; update layer progress
M73 L5
M991 S0 P4 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.2 I-.101 J1.213 P1  F42000
G1 X88.991 Y86.991 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.4
M73 P80 R1
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.4 F4000
            G39.3 S1
            G0 Z1.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X81.357 Y84.486 F42000
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.357 Y86.114 E.05401
G1 X81.886 Y86.643 E.02478
G1 X82.357 Y86.643 E.01565
G1 X87.643 Y81.357 E.24794
G1 X88.114 Y81.357 E.01565
G1 X88.643 Y81.886 E.02478
G1 X88.643 Y86.114 E.14027
G1 X88.114 Y86.643 E.02478
G1 X87.643 Y86.643 E.01565
G1 X82.357 Y81.357 E.24794
G1 X81.886 Y81.357 E.01565
G1 X81.357 Y81.886 E.02478
G1 X81.357 Y83.514 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F8843.478
G1 X81.357 Y81.886 E-.61876
G1 X81.62 Y81.623 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 6/14
; update layer progress
M73 L6
M991 S0 P5 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.4 I-.716 J.984 P1  F42000
G1 X88.991 Y86.991 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
M73 P81 R1
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.6
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.6 F4000
            G39.3 S1
            G0 Z1.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X81.357 Y83.514 F42000
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.357 Y81.886 E.05401
G1 X81.886 Y81.357 E.02478
G1 X82.357 Y81.357 E.01565
G1 X87.643 Y86.643 E.24794
G1 X88.114 Y86.643 E.01565
G1 X88.643 Y86.114 E.02478
G1 X88.643 Y81.886 E.14027
G1 X88.114 Y81.357 E.02478
G1 X87.643 Y81.357 E.01565
G1 X82.357 Y86.643 E.24794
G1 X81.886 Y86.643 E.01565
G1 X81.357 Y86.114 E.02478
G1 X81.357 Y84.486 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F8843.478
G1 X81.357 Y86.114 E-.61876
G1 X81.62 Y86.377 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 7/14
; update layer progress
M73 L7
M991 S0 P6 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
M73 P82 R1
G3 Z1.6 I-.101 J1.213 P1  F42000
G1 X88.991 Y86.991 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z1.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z1.8
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z1.8 F4000
            G39.3 S1
            G0 Z1.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X81.357 Y84.486 F42000
M73 P83 R1
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.357 Y86.114 E.05401
G1 X81.886 Y86.643 E.02478
G1 X82.357 Y86.643 E.01565
G1 X87.643 Y81.357 E.24794
G1 X88.114 Y81.357 E.01565
G1 X88.643 Y81.886 E.02478
G1 X88.643 Y86.114 E.14027
G1 X88.114 Y86.643 E.02478
G1 X87.643 Y86.643 E.01565
G1 X82.357 Y81.357 E.24794
G1 X81.886 Y81.357 E.01565
G1 X81.357 Y81.886 E.02478
G1 X81.357 Y83.514 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F8843.478
G1 X81.357 Y81.886 E-.61876
G1 X81.62 Y81.623 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 8/14
; update layer progress
M73 L8
M991 S0 P7 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z1.8 I-.716 J.984 P1  F42000
G1 X88.991 Y86.991 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
M73 P84 R1
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2 F4000
            G39.3 S1
            G0 Z2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X81.357 Y83.514 F42000
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.357 Y81.886 E.05401
G1 X81.886 Y81.357 E.02478
G1 X82.357 Y81.357 E.01565
G1 X87.643 Y86.643 E.24794
G1 X88.114 Y86.643 E.01565
G1 X88.643 Y86.114 E.02478
G1 X88.643 Y81.886 E.14027
G1 X88.114 Y81.357 E.02478
G1 X87.643 Y81.357 E.01565
G1 X82.357 Y86.643 E.24794
G1 X81.886 Y86.643 E.01565
G1 X81.357 Y86.114 E.02478
G1 X81.357 Y84.486 E.05401
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F8843.478
G1 X81.357 Y86.114 E-.61876
G1 X81.62 Y86.377 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 9/14
; update layer progress
M73 L9
M991 S0 P8 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2 I-.101 J1.213 P1  F42000
G1 X88.991 Y86.991 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
M73 P85 R1
G1 F1200
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.2
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.2 F4000
            G39.3 S1
            G0 Z2.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X88.469 Y81.372 F42000
G1 Z1.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383598
G1 F1200
M204 S6000
G1 X81.531 Y81.372 E.1926
M73 P86 R1
G1 X81.399 Y81.399 E.00374
G1 X81.372 Y81.531 E.00374
G1 X81.372 Y86.469 E.13708
G1 X81.399 Y86.601 E.00374
G1 X81.531 Y86.628 E.00374
G1 X88.469 Y86.628 E.1926
G1 X88.601 Y86.601 E.00374
G1 X88.628 Y86.469 E.00374
G1 X88.628 Y81.531 E.13708
G1 X88.601 Y81.399 E.00374
G1 X88.528 Y81.384 E.00207
M204 S10000
G1 X81.735 Y82.363 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.45
G1 F1200
M204 S6000
G1 X81.735 Y81.735 E.02084
G1 X82.735 Y81.735 E.03317
G1 X87.265 Y86.265 E.21255
G1 X82.735 Y86.265 E.1503
G1 X87.265 Y81.735 E.21255
G1 X88.265 Y81.735 E.03317
G1 X88.265 Y82.363 E.02084
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F8843.478
G1 X88.265 Y81.735 E-.23876
G1 X87.265 Y81.735 E-.38
G1 X87.003 Y81.997 E-.14124
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 10/14
; update layer progress
M73 L10
M991 S0 P9 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.2 I-1.131 J.45 P1  F42000
G1 X88.991 Y86.991 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1200
M204 S6000
M73 P87 R1
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1200
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1200
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.4 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.4
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.4 F4000
            G39.3 S1
            G0 Z2.4 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X87.913 Y86.824 F42000
G1 Z2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40068
; LAYER_HEIGHT: 0.4
M106 S255
G1 F3000
M204 S6000
G1 X88.621 Y86.115 E.05148
G1 X88.621 Y85.478 E.03274
G1 X87.478 Y86.621 E.08308
G1 X86.84 Y86.621 E.03274
G1 X88.621 Y84.84 E.12938
G1 X88.621 Y84.203 E.03274
G1 X86.203 Y86.621 E.17569
G1 X85.566 Y86.621 E.03274
G1 X88.621 Y83.566 E.222
G1 X88.621 Y82.928 E.03274
G1 X84.928 Y86.621 E.2683
G1 X84.291 Y86.621 E.03274
G1 X88.621 Y82.291 E.31461
G1 X88.621 Y81.654 E.03274
G1 X83.654 Y86.621 E.36092
G1 X83.016 Y86.621 E.03274
G1 X88.258 Y81.379 E.38087
G1 X87.621 Y81.379 E.03274
G1 X82.379 Y86.621 E.38087
G1 X81.741 Y86.621 E.03274
G1 X86.984 Y81.379 E.38087
M73 P88 R1
G1 X86.346 Y81.379 E.03274
G1 X81.379 Y86.346 E.36091
G1 X81.379 Y85.709 E.03274
G1 X85.709 Y81.379 E.3146
G1 X85.072 Y81.379 E.03274
G1 X81.379 Y85.072 E.2683
G1 X81.379 Y84.434 E.03274
M73 P88 R0
G1 X84.434 Y81.379 E.22199
G1 X83.797 Y81.379 E.03274
G1 X81.379 Y83.797 E.17568
G1 X81.379 Y83.16 E.03274
G1 X83.16 Y81.379 E.12938
G1 X82.522 Y81.379 E.03274
G1 X81.379 Y82.522 E.08307
G1 X81.379 Y81.885 E.03274
G1 X82.087 Y81.176 E.05148
M106 S204
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F3000
G1 X81.379 Y81.885 E-.38076
G1 X81.379 Y82.522 E-.2422
G1 X81.634 Y82.267 E-.13705
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 11/14
; update layer progress
M73 L11
M991 S0 P10 ;notify layer change
M106 S201.45
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.4 I-.658 J1.024 P1  F42000
G1 X88.991 Y86.991 Z2.4
G1 Z2.2
M73 P89 R0
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1721
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1721
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1721
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.6 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.6
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.6 F4000
            G39.3 S1
            G0 Z2.6 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X86.262 Y84 F42000
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56784
G1 F1721
M204 S6000
G1 X86.262 Y83.738 E.01123
G1 X83.738 Y83.738 E.108
G1 X83.738 Y84.262 E.02245
G1 X86.262 Y84.262 E.108
G1 X86.262 Y84.06 E.00866
M204 S10000
G1 X86.713 Y84 F42000
; LINE_WIDTH: 0.41999
G1 F1721
M204 S6000
G1 X86.713 Y83.287 E.02192
G1 X83.287 Y83.287 E.1053
G1 X83.287 Y84.713 E.04384
G1 X86.713 Y84.713 E.1053
G1 X86.713 Y84.06 E.02008
M204 S10000
G1 X87.091 Y84 F42000
G1 F1721
M204 S6000
G1 X87.091 Y82.909 E.03351
G1 X82.909 Y82.909 E.12847
G1 X82.909 Y85.091 E.06702
G1 X87.091 Y85.091 E.12847
G1 X87.091 Y84.06 E.03166
M204 S10000
G1 X87.468 Y84 F42000
G1 F1721
M204 S6000
G1 X87.468 Y82.532 E.04509
G1 X82.532 Y82.532 E.15164
G1 X82.532 Y85.468 E.09019
G1 X87.468 Y85.468 E.15164
G1 X87.468 Y84.06 E.04325
M204 S10000
G1 X87.845 Y84 F42000
G1 F1721
M204 S6000
G1 X87.845 Y82.155 E.05668
G1 X82.155 Y82.155 E.17481
G1 X82.155 Y85.845 E.11336
G1 X87.845 Y85.845 E.17481
G1 X87.845 Y84.06 E.05484
M204 S10000
G1 X88.222 Y84 F42000
M73 P90 R0
G1 F1721
M204 S6000
G1 X88.222 Y81.778 E.06827
G1 X81.778 Y81.778 E.19799
G1 X81.778 Y86.222 E.13653
G1 X88.222 Y86.222 E.19799
G1 X88.222 Y84.06 E.06642
M204 S10000
G1 X88.599 Y84 F42000
G1 F1721
M204 S6000
G1 X88.599 Y81.401 E.07985
G1 X81.401 Y81.401 E.22116
G1 X81.401 Y86.599 E.1597
G1 X88.599 Y86.599 E.22116
G1 X88.599 Y84.06 E.07801
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9547.299
G1 X88.599 Y86.06 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 12/14
; update layer progress
M73 L12
M991 S0 P11 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.6 I-1.122 J.472 P1  F42000
G1 X88.991 Y86.991 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1711
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1711
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1711
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z2.8 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z2.8
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z2.8 F4000
            G39.3 S1
            G0 Z2.8 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X86.262 Y84 F42000
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56784
G1 F1711
M204 S6000
G1 X86.262 Y83.738 E.01123
G1 X83.738 Y83.738 E.108
G1 X83.738 Y84.262 E.02245
G1 X86.262 Y84.262 E.108
G1 X86.262 Y84.06 E.00866
M204 S10000
G1 X86.713 Y84 F42000
; LINE_WIDTH: 0.41999
M73 P91 R0
G1 F1711
M204 S6000
G1 X86.713 Y83.287 E.02192
G1 X83.287 Y83.287 E.1053
G1 X83.287 Y84.713 E.04384
G1 X86.713 Y84.713 E.1053
G1 X86.713 Y84.06 E.02008
M204 S10000
G1 X87.091 Y84 F42000
G1 F1711
M204 S6000
G1 X87.091 Y82.909 E.03351
G1 X82.909 Y82.909 E.12847
G1 X82.909 Y85.091 E.06702
G1 X87.091 Y85.091 E.12847
G1 X87.091 Y84.06 E.03166
M204 S10000
G1 X87.468 Y84 F42000
G1 F1711
M204 S6000
G1 X87.468 Y82.532 E.04509
G1 X82.532 Y82.532 E.15164
G1 X82.532 Y85.468 E.09019
G1 X87.468 Y85.468 E.15164
G1 X87.468 Y84.06 E.04325
M204 S10000
G1 X87.845 Y84 F42000
G1 F1711
M204 S6000
G1 X87.845 Y82.155 E.05668
G1 X82.155 Y82.155 E.17481
G1 X82.155 Y85.845 E.11336
G1 X87.845 Y85.845 E.17481
G1 X87.845 Y84.06 E.05484
M204 S10000
G1 X88.222 Y84 F42000
G1 F1711
M204 S6000
G1 X88.222 Y81.778 E.06827
G1 X81.778 Y81.778 E.19799
G1 X81.778 Y86.222 E.13653
G1 X88.222 Y86.222 E.19799
G1 X88.222 Y84.06 E.06642
M204 S10000
G1 X88.599 Y84 F42000
G1 F1711
M204 S6000
G1 X88.599 Y81.401 E.07985
G1 X81.401 Y81.401 E.22116
G1 X81.401 Y86.599 E.1597
M73 P92 R0
G1 X88.599 Y86.599 E.22116
G1 X88.599 Y84.06 E.07801
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9547.299
G1 X88.599 Y86.06 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 13/14
; update layer progress
M73 L13
M991 S0 P12 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z2.8 I-1.122 J.472 P1  F42000
G1 X88.991 Y86.991 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.45
G1 F1711
M204 S6000
G1 X81.009 Y86.991 E.26477
G1 X81.009 Y81.009 E.19843
G1 X88.991 Y81.009 E.26477
G1 X88.991 Y86.931 E.19643
M204 S10000
G1 X89.398 Y87.398 F42000
G1 F1711
M204 S6000
G1 X80.602 Y87.398 E.29178
G1 X80.602 Y80.602 E.22543
G1 X89.398 Y80.602 E.29178
G1 X89.398 Y87.338 E.22344
M204 S250
G1 X89.79 Y87.79 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1711
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3 F4000
            G39.3 S1
            G0 Z3 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X86.262 Y84 F42000
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.56784
G1 F1711
M204 S6000
G1 X86.262 Y83.738 E.01123
G1 X83.738 Y83.738 E.108
G1 X83.738 Y84.262 E.02245
G1 X86.262 Y84.262 E.108
G1 X86.262 Y84.06 E.00866
M204 S10000
G1 X86.713 Y84 F42000
; LINE_WIDTH: 0.41999
G1 F1711
M204 S6000
G1 X86.713 Y83.287 E.02192
G1 X83.287 Y83.287 E.1053
G1 X83.287 Y84.713 E.04384
G1 X86.713 Y84.713 E.1053
G1 X86.713 Y84.06 E.02008
M204 S10000
G1 X87.091 Y84 F42000
G1 F1711
M204 S6000
G1 X87.091 Y82.909 E.03351
G1 X82.909 Y82.909 E.12847
G1 X82.909 Y85.091 E.06702
G1 X87.091 Y85.091 E.12847
G1 X87.091 Y84.06 E.03166
M204 S10000
G1 X87.468 Y84 F42000
G1 F1711
M204 S6000
G1 X87.468 Y82.532 E.04509
G1 X82.532 Y82.532 E.15164
G1 X82.532 Y85.468 E.09019
G1 X87.468 Y85.468 E.15164
M73 P93 R0
G1 X87.468 Y84.06 E.04325
M204 S10000
G1 X87.845 Y84 F42000
G1 F1711
M204 S6000
G1 X87.845 Y82.155 E.05668
G1 X82.155 Y82.155 E.17481
G1 X82.155 Y85.845 E.11336
G1 X87.845 Y85.845 E.17481
G1 X87.845 Y84.06 E.05484
M204 S10000
G1 X88.222 Y84 F42000
G1 F1711
M204 S6000
G1 X88.222 Y81.778 E.06827
G1 X81.778 Y81.778 E.19799
G1 X81.778 Y86.222 E.13653
G1 X88.222 Y86.222 E.19799
G1 X88.222 Y84.06 E.06642
M204 S10000
G1 X88.599 Y84 F42000
G1 F1711
M204 S6000
G1 X88.599 Y81.401 E.07985
G1 X81.401 Y81.401 E.22116
G1 X81.401 Y86.599 E.1597
G1 X88.599 Y86.599 E.22116
G1 X88.599 Y84.06 E.07801
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; WIPE_START
G1 F9547.299
G1 X88.599 Y86.06 E-.76
; WIPE_END
G1 E-.04 F1800
; layer num/total_layer_count: 14/14
; update layer progress
M73 L14
M991 S0 P13 ;notify layer change
; OBJECT_ID: 15
M204 S10000
G17
G3 Z3 I-1.002 J.69 P1  F42000
G1 X89.79 Y87.79 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.42
G1 F1996
M204 S5000
G1 X80.21 Y87.79 E.29437
G1 X80.21 Y80.21 E.23291
G1 X89.79 Y80.21 E.29437
G1 X89.79 Y87.73 E.23107
; WIPE_START
G1 F9547.055
M204 S6000
G1 X87.79 Y87.743 E-.76
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.2 I1.217 J0 P1  F42000
;===================== date: 20250206 =====================

; don't support timelapse gcode in spiral_mode and by object sequence for I3 structure printer
; SKIPPABLE_START
; SKIPTYPE: timelapse
M622.1 S1 ; for prev firmware, default turned on
M1002 judge_flag timelapse_record_flag
M622 J1
G92 E0
G1 Z3.2
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos
M400
M1004 S5 P1  ; external shutter
M400 P300
M971 S11 C11 O0
G92 E0
M73 P94 R0
G1 X0 F18000
M623

; SKIPTYPE: head_wrap_detect
M622.1 S1
M1002 judge_flag g39_3rd_layer_detect_flag
M622 J1
    ; enable nozzle clog detect at 3rd layer
    


    M622.1 S1
    M1002 judge_flag g39_detection_flag
    M622 J1
      
        M622.1 S0
        M1002 judge_flag g39_mass_exceed_flag
        M622 J1
        
            G392 S0
            M400
            G90
            M83
            M204 S5000
            G0 Z3.2 F4000
            G39.3 S1
            G0 Z3.2 F4000
            G392 S0
          
        M623
    
    M623
M623
; SKIPPABLE_END




G1 X89.15 Y87.583 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Top surface
G1 F1996
M204 S2000
G1 X89.583 Y87.15 E.01882
G1 X89.583 Y86.616
G1 X88.616 Y87.583 E.04199
G1 X88.083 Y87.583
G1 X89.583 Y86.083 E.06517
G1 X89.583 Y85.55
G1 X87.55 Y87.583 E.08834
G1 X87.017 Y87.583
G1 X89.583 Y85.017 E.11151
G1 X89.583 Y84.483
G1 X86.483 Y87.583 E.13468
G1 X85.95 Y87.583
G1 X89.583 Y83.95 E.15786
G1 X89.583 Y83.417
G1 X85.417 Y87.583 E.18103
G1 X84.883 Y87.583
G1 X89.583 Y82.883 E.2042
G1 X89.583 Y82.35
G1 X84.35 Y87.583 E.22737
G1 X83.817 Y87.583
G1 X89.583 Y81.817 E.25055
G1 X89.583 Y81.284
G1 X83.284 Y87.583 E.27372
G1 X82.75 Y87.583
G1 X89.583 Y80.75 E.29689
G1 X89.382 Y80.417
G1 X82.217 Y87.583 E.31137
G1 X81.684 Y87.583
G1 X88.849 Y80.417 E.31137
G1 X88.316 Y80.417
G1 X81.151 Y87.583 E.31137
G1 X80.617 Y87.583
G1 X87.783 Y80.417 E.31137
G1 X87.249 Y80.417
G1 X80.417 Y87.249 E.29689
G1 X80.417 Y86.716
G1 X86.716 Y80.417 E.27371
G1 X86.183 Y80.417
G1 X80.417 Y86.183 E.25054
G1 X80.417 Y85.65
G1 X85.65 Y80.417 E.22737
G1 X85.116 Y80.417
G1 X80.417 Y85.116 E.2042
G1 X80.417 Y84.583
G1 X84.583 Y80.417 E.18102
G1 X84.05 Y80.417
G1 X80.417 Y84.05 E.15785
G1 X80.417 Y83.517
G1 X83.517 Y80.417 E.13468
M73 P95 R0
G1 X82.983 Y80.417
G1 X80.417 Y82.983 E.1115
G1 X80.417 Y82.45
G1 X82.45 Y80.417 E.08833
G1 X81.917 Y80.417
G1 X80.417 Y81.917 E.06516
G1 X80.417 Y81.384
G1 X81.384 Y80.417 E.04199
G1 X80.85 Y80.417
G1 X80.417 Y80.85 E.01881
; WIPE_START
G1 F9547.055
M204 S6000
G1 X80.85 Y80.417 E-.23267
G1 X81.384 Y80.417 E-.20264
G1 X80.779 Y81.022 E-.32469
; WIPE_END
G1 E-.04 F1800
M204 S10000
G1 X80.488 Y87.32 Z3.2 F42000
G1 Z2.8
G1 E.8 F1800
; FEATURE: Gap infill
; LINE_WIDTH: 0.147644
G1 F1996
M204 S6000
G1 X80.449 Y87.414 E.00087
G1 X80.449 Y87.601 E.0016
; close powerlost recovery
M1003 S0
; WIPE_START
G1 F15000
G1 X80.449 Y87.414 E-.49251
G1 X80.488 Y87.32 E-.26749
; WIPE_END
G1 E-.04 F1800
M204 S10000
G17
G3 Z3.2 I1.217 J0 P1  F42000
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
; filament end gcode 

;===== date: 20260513 =====================
;turn off nozzle clog detect
G392 S0

M400 ; wait for buffer to clear
G92 E0 ; zero the extruder
G90
G1 Z3.2 F900 ; lower z a little
G1 X0 Y84 F18000 ; move to safe pos
G1 X-13.0 F3000 ; move to safe pos

M1002 judge_flag timelapse_record_flag
M622 J1
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M400 P100
M971 S11 C11 O0
M991 S0 P-1 ;end timelapse at safe pos
M623


M140 S0 ; turn off bed
M106 S0 ; turn off fan
M106 P2 S0 ; turn off remote part cooling fan
M106 P3 S0 ; turn off chamber cooling fan

;G1 X27 F15000 ; wipe

; pull back filament to AMS
M620 S255
G1 X181 F12000
T255
G1 X0 F18000
G1 X-13.0 F3000
G1 X0 F18000 ; wipe
M621 S255

M104 S0 ; turn off hotend

M400 ; wait all motion done
M17 S
M17 Z0.4 ; lower z motor current to reduce impact if there is something in the bottom

    G1 Z102.8 F600
    G1 Z100.8

M400 P100
M17 R ; restore z current

G90
G1 X-13 Y180 F3600

G91
G1 Z-1 F600
G90
M83

M220 S100  ; Reset feedrate magnitude
M201.2 K1.0 ; Reset acc magnitude
M73.2   R1.0 ;Reset left time magnitude
M1002 set_gcode_claim_speed_level : 0

;=====printer finish  sound=========
M17
M400 S1
M1006 S1
M1006 A0 B20 L100 C37 D20 M100 E42 F20 N100
M1006 A0 B10 L100 C44 D10 M100 E44 F10 N100
M1006 A0 B10 L100 C46 D10 M100 E46 F10 N100
M1006 A44 B20 L100 C39 D20 M100 E48 F20 N100
M1006 A0 B10 L100 C44 D10 M100 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B10 L100 C39 D10 M100 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B10 L100 C44 D10 M100 E44 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A0 B10 L100 C39 D10 M100 E39 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A44 B10 L100 C0 D10 M100 E48 F10 N100
M1006 A0 B10 L100 C0 D10 M100 E0 F10 N100
M1006 A44 B20 L100 C41 D20 M100 E49 F20 N100
M1006 A0 B20 L100 C0 D20 M100 E0 F20 N100
M1006 A0 B20 L100 C37 D20 M100 E37 F20 N100
M1006 W
;=====printer finish  sound=========
M400 S1
M18 X Y Z
M73 P100 R0
; EXECUTABLE_BLOCK_END

